# Credits and source attribution

This combined mod incorporates content and assets from the following upstream projects:
- Deciv2 (base ruleset and assets)
- Outlaws of the Wastes (ruleset additions/overrides and assets)
- Forgotten Factions for Deciv (civilizations, ruleset additions and assets)

Original credit files and changelogs are preserved in `SOURCE_DOCUMENTATION/`.
Please consult those files and the upstream repositories for author credits, permissions, and license terms.
