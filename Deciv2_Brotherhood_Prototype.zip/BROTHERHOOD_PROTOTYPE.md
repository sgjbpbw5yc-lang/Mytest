# Brotherhood of Steel — prototype 0.1

This is a mechanics prototype added to the merged DeCiv 2 + Outlaws + Forgotten Factions ruleset. It is not a finished civilization.

## Implemented
- Civilization: Brotherhood of Steel, provisional leader Elder Maxson.
- Stockpiled resource: Salvage. It does not generate naturally and is hidden from other civilizations.
- UA: earns 10% of the production cost of defeated military units as Salvage.
- UU: Brotherhood Paladin replaces Infantry, costs 8 Salvage, costs 160 Production, and retains the normal Weapons consumption.
- Temporary icons reuse existing DeCiv art; replace with original Brotherhood artwork later.

## Intended test
1. Start a game as Brotherhood of Steel.
2. Defeat enemy military units and check whether Salvage increases by 10% of each defeated unit's listed production cost.
3. Attempt to queue Brotherhood Paladins with fewer than 8 Salvage; construction should be blocked.
4. Accumulate at least 8 Salvage and queue a Paladin; confirm that the resource is deducted when construction begins.
5. Check whether upgrading a Paladin to NBC Infantry bypasses Salvage. This is expected to be possible under the current prototype and is a balance question, not a validation failure.
6. Check whether bought units consume Salvage in the same way as production-built units.

## Validation status
- JSON syntax: checked.
- ZIP integrity: checked.
- Cross-references: required tech, replacement unit, upgrade target, civilization, and stockpile names checked against the merged ruleset.
- Runtime validation: not yet performed in Unciv. The in-game Ruleset Validator and the six gameplay checks above remain necessary.

## Open balance questions
- Is 10% salvage yield and an 8-Salvage Paladin cost too generous or too restrictive?
- Should Paladin upgrades retain the Brotherhood identity instead of upgrading into standard NBC Infantry?
- Should Salvage also fund a building or a second elite unit, or remain a narrow military resource?
