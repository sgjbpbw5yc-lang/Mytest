# Deciv2 + Outlaws of the Wastes + Forgotten Factions

A standalone Unciv mod combining Deciv2 as the foundation, Outlaws of the Wastes as the ruleset overlay, and Forgotten Factions as additional content.

## Repository layout

The repository root is the mod root. It contains `jsons/`, image directories, texture atlases, `Atlases.json`, and optional sounds. Do not upload an extra enclosing folder level.

## Install from GitHub

1. Open Unciv and open the Mods manager.
2. Choose **Download mod from URL** (wording may vary by build).
3. Paste this repository's public GitHub URL.
4. Download, enable the mod, and start a new game for a clean test.

## Notes

- The merged JSON ruleset is carried forward from the agreed three-way merge.
- Original artwork and source atlas pages from all three mods are retained. Where source atlases shared a logical name, their pages are combined into one atlas file with unique page-image names.
- The mod has not been validated inside the exact iOS TestFlight build. Please report any missing icon, atlas, or loading errors.
- Source changelogs, READMEs, and credits are retained in `SOURCE_DOCUMENTATION/`. See `Credits.md` for attribution pointers.
