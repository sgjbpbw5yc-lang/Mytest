# Compatibility and validation report

## Merge policy
- Deciv2 is the base ruleset.
- Outlaws is treated as the primary addon: its intentional overrides of Deciv2 remain authoritative.
- FF additions are retained. Where FF and Outlaws modify the same object, compatible fields and string-list additions are merged.
- Three irreconcilable required-tech differences remain documented below. The package provisionally keeps the Outlaws prerequisite because Outlaws is the primary addon; FF's compatible `happiness: 1` addition is retained.

## User-confirmed Mountain decisions
- Mountain damage is **50**.
- The Outlaws `Impeded terrain` unique is retained.
- FF's `Becomes [Desert Mountain] when adjacent to [Desert]` behavior is retained.
- `unbuildable` was removed from Mountain and Desert Mountain so Mountain improvements can be built there.
- Desert Mountain retains its own FF damage value of 30; the user specified 50 for Mountain, not for the Desert Mountain feature.

## Changelog / compatibility fixes
- Deciv2's changelog content and balance updates were retained through the Deciv2 base, with Outlaws/FF overlays merged on top.
- Spring: removed the contradictory `unbuildable` flag while retaining `Only [Water pump] improvements may be built on this tile`.
- Offshore mine: retained Outlaws' `turnsToBuild: 8` and restored Deciv2's Cobalt yield unique.
- Mountain improvements: added `Desert Mountain` to the buildable-terrain lists for Moisture trap, Artificial glacier, and Tunnel, in addition to Mountain.
- Mountain: removed FF's `unbuildable` flag and preserved the Outlaws `Impeded terrain` unique.
- Desert Mountain: removed FF's `unbuildable` flag so the same mountain improvements can be built on the feature.

## Three unresolved source conflicts
The same FF/Outlaws building definitions have different `requiredTech` values:
| Building | Outlaws prerequisite retained | FF prerequisite |
|---|---|---|
| Resonance Node | Electronics | Civil Service |
| Trial by Combat | Hoplology | Civil Service |
| Secret Totem | Ecotheory | Civil Service |

The package retains the Outlaws prerequisite in each case and merges FF's `happiness: 1` field. These are the only three addon-vs-addon scalar conflicts detected by the merge routine. If the intended prerequisite should instead be Civil Service, these three values can be changed.

## Orphaned civilization restrictions
Thirteen `uniqueTo` restrictions referring to seven civilizations absent from the merged Nations list were removed; the associated buildings, improvements, and units were retained as general content. The missing civilization names were: Geneva Union, Russian Unifier, Cyberapes, Charybdis Division, TCC, Seekers of Eden, and Reactorland.

## Source JSON repairs
Eight source JSON files contained syntax errors (missing commas). Seventeen comma insertions were made in the working copies to make the files parse:
- Deciv2: UnitPromotions.json (1), TileSets/FantasyHex.json (1)
- FF: Religions.json (1), Personalities.json (1), Units.json (4), Nations.json (3), Buildings.json (5), TileResources.json (1)

No source file content was intentionally dropped due to these syntax errors. Repaired files were serialized as strict JSON in the output.

## Automated validation
- 26 JSON files emitted.
- All 26 parse successfully with Python's strict JSON parser.
- No duplicate top-level named objects detected.
- All building/unit/improvement `requiredTech` / `techRequired` references resolve to a merged tech.
- All unit promotion references resolve.
- All remaining `uniqueTo` civilization references resolve to a merged Nation.
- The merged Techs list contains 77 distinct technologies.
- Content counts: 666 buildings, 384 units, 68 nations, 83 tile improvements, 70 tile resources, 41 terrain definitions, and 177 unit promotions.

## Important limitation
This is structural JSON validation, not an in-engine Unciv playtest. The source archives contained JSON files only; missing sprites, sounds, fonts, or other assets from the original mods are not invented or included. Test the mod in Unciv before using it in a long-running save.
