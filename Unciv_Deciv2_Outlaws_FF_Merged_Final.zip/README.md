# Deciv2 + Outlaws + FF (standalone merged mod)

This package combines the Deciv2 ruleset with the Outlaws and FF add-ons into one mod folder. It does not require the three source mods to be installed separately.

## Install
1. Extract this ZIP.
2. Copy the extracted mod folder (the folder containing `jsons/`) into your Unciv mods directory.
3. Enable the merged mod in Unciv.

The archive contains the JSON content supplied in the three source archives, merged into a single `jsons/` tree. The source archives did not include a complete mod metadata/artwork package, so this merge does not fabricate missing assets or metadata.

See `COMPATIBILITY_AND_VALIDATION.md` for merge decisions, source repairs, and validation limits.
